                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1851632
Curvaceous Vase by markwheadon is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is scaled to 20cm tall by default, but you can scale it to any size you require.

It's a solid so best printed in spiral vase mode, and it looks particularly stunning in Faberdashery translucent PLA.

I suggest a single 0.55mm perimeter sliced in spiral vase mode. (Say) five bottom layers.

If your slicer doesn't do spiral vase mode then slice it with five bottom layers, no top layers, one perimeter (0.55-ish mm) and no fill.

Then add flowers!

# Print Settings

Printer Brand: RepRap
Printer: Kossel Mini
Rafts: No
Supports: No
Resolution: 0.2mm (bigger for better translucence)
Infill: None

Notes: 
0.55mm-ish perimeter, and only one.
A few bottom layers to give it a bit of stability, no fill, no top layers.

Or better still: spiral vase mode.